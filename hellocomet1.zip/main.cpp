/*
module: assign_HelloWorld_Diamond_Draw solution
date: 2023-8-25
Author: Oudom Pach
Module Purpose
print out a diamond that includes the word "Hello comet" in the middle
*/




#include        <string>
#include        <iostream>
using namespace std;

int main() {
    cout << "Temoc, enarc and Scorcher say :" << endl << endl;

    cout << "        *" << endl;
    cout << "       * *" << endl;
    cout << "      *   *" << endl;
    cout << "     *     *" << endl;
    cout << "    *       *" << endl;
    cout << "   *         *" << endl;
    cout << "  *           *" << endl;
    cout << " * Hello Comet *" << endl;
    cout << "  *           *" << endl;
    cout << "   *         *" << endl;
    cout << "    *       *" << endl;
    cout << "     *     *" << endl;
    cout << "      *   *" << endl;
    cout << "       * *" << endl;
    cout << "        *" << endl;


    return EXIT_SUCCESS;

}





