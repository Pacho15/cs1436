/*
Program Name: Files Copy
Date Written: 2023-10-19
Author:       Oudom Pach
Program Purpose: uses basic file input and out operations using streams that copy and prints out a list of names while also counting how many lines there are.
*/


#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>

using namespace std;

int main() {


    const string myIFileName = "names.txt"; 

    const string myOFileName = "namescopy.txt"; 




    ifstream myIFile(myIFileName); 


    if (myIFile.fail()) {

        cerr << "Error opening the file " << myIFileName << endl;
        exit(EXIT_FAILURE);

    }

    fstream myOFile(myOFileName);

    if (myOFile.fail()) {

        cerr << "Error opening the file " << myOFileName << endl;
        exit(EXIT_FAILURE);

    }

    string myIFileLine;
    unsigned nameCount = 0;

    cout << "Lines in the input file :\n" << endl;


    while (getline(myIFile, myIFileLine)) {
        cout << myIFileLine << endl;
        myOFile << myIFileLine << endl;
        nameCount++;

    }
    

    myOFile.close();
    myOFile.open(myOFileName);
 
    cout << endl << "Lines in the output file :\n" << endl;

    while (getline(myOFile, myIFileLine)) {

        cout << myIFileLine << endl;
    }

    cout << endl;
    cout << "Number of names read from file: " << nameCount << endl;

    myIFile.close();
    myOFile.close();


    return 0;
}