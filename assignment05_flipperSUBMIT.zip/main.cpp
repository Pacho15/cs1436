/*

PROGRAM NAME: Flipper
Date: 2023-9-26
Author: Oudom Pach
flips a coin and records head or tails while tallying up the scores and flips.

*/




#include <iostream>
using namespace std;

int main(){

    int flips;


    srand(clock());

    cout << "How many flips of the coin do you want? ";
    cin >> flips;

    int i =  1;
    int headCount = 0;
    int tailCount = 0;

    for (i = 1; i <= flips; i++) {

        //cout << "test" << endl;

        int result = ((rand() % 2) + 1);
        if (result == 1) {
            cout << i << " : " << "Tails" << endl;;
            tailCount++;
        }
        else if (result == 2) {
            cout << i << " : " << "Heads" << endl;
            headCount++;
        }
    }

    cout << endl;

    cout << "Total Flip Count: " << flips << endl;

    cout << "Total Heads Count: " << headCount << endl;

    cout << "Total Tails Count: " << tailCount << endl;






    return 0;
}