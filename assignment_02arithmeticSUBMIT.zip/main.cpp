/*
Arithmetic String assignment 02
8/30/23
Oudom Pach
output all the results of the requested operations

*/


#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <stdio.h>
#include <math.h> //its used for power function

using namespace std;


//need to figure out format*********
int main() {
    
    //iomanips
    

    //defines int to later then be cin and converted
    int intToConvert;
    cout << "Please enter an integer to convert: "; cin >> intToConvert;
    cout << endl << endl;

    cout << "Use iomanips to condiion the stream " << endl;
    cout << "The entered integer in octal        form is: " << oct << intToConvert << endl;
    cout << "The entered integer in hexadecimal  form is: " << hex << intToConvert << endl;
    cout << "The entered integer in decimal      form is: " << dec << intToConvert << endl;
    cout << endl; 

    cout << "Use iomanips setbase to format what follows in the stream " << endl;
    cout << "The entered integer in octal        form is: " << setbase(8) << intToConvert << endl;
    cout << "The entered integer in hexadecimal  form is: " << setbase(16) << intToConvert << endl;
    cout << "The entered integer in decimal      form is: " << setbase(10) << intToConvert << endl;
    cout << endl; 

    
    //defines int to later be shifted to multiply by 4
    int intToShift;
    cout << endl;
    cout << "Please enter an integer to shift to multiply 4 : "; cin >> intToShift; 
    int intLeftShift = intToShift << 2;
    int intRightShift = intToShift >> 2;
    cout << "This integer multiplied by 4 with  left shift binary operator is : " << intLeftShift << endl;
    cout << "This integer divided    by 4 with right shift binary operator is : " << intRightShift << endl;

    //list the bytes of all the data types
    cout << endl;
    cout << "All sizes are in Bytes: \n";
    cout << "char size:       " << sizeof(char) << endl;
    cout << "short size:      " << sizeof(short) << endl;
    cout << "int size:        " << sizeof(int) << endl;
    cout << "unsigned size:   " << sizeof(unsigned) << endl;
    cout << "long size:       " << sizeof(long) << endl;
    cout << "long long size:  " << sizeof(long long) << endl;
    cout << "bool size:       " << sizeof(bool) << endl;
    cout << "float size:      " << sizeof(float) << endl;
    cout << "double size:     " << sizeof(double) << endl;


    //converts int to char
    cout << endl;
    int intChar;
    cout << "Please enter a number for a char: "; cin >> intChar; 
    char charValue = static_cast<char> (intChar);
    cout << "Character for int c is : " << charValue << endl;


    //converts negative number to a unsigned int
    cout << endl;
    int negInt;
    cout << "Please enter a negative number: "; cin >> negInt; 

    unsigned unsignedInt = static_cast<unsigned> (negInt);
    cout << "The unsigned int is: " << unsignedInt << endl;
    cout << endl; 

    //i manipulation portable
    int i = 1;
    i = i / i++;
    cout << "int i = 1; i = i / i++;" << endl << "i is " << i << endl;
    cout << endl;

    i = 0;
    i = i * ++i;
    cout << "i = 0; i = i * ++i;" << endl << "The value of i is " << i << endl;
    cout << endl;

    i = 0;
    i = (i = i + 1) + (i = i + 2);
    cout << "i = 0; i = (i = i + 1) + (i = i + 2);" << endl << "The value for i is : " << i << endl;
    cout << endl;

    bool a = true;
    bool b = false;
    a = (b = false) && (b++); 
    cout << "bool a = true, b = false; a = (b = false) && (b++); : " << endl;
    cout << "a is " << a << endl;
    cout << "b is " << b << endl;
    cout << endl;
  
    //input => output user input integers
    cout << endl;
    int firstInt;
    int secondInt;
    cout << "Please enter a 1st integer : "; cin >> firstInt;
    cout << "Please enter a 2nd integer : "; cin >> secondInt; 
    cout << endl;
    cout << "The entered 1st integer is : " << firstInt << endl;
    cout << "The entered 2nd integer is : " << secondInt << endl;


    //perform math operations on the integers
    cout << endl;
    cout << " The sum of the two integers is :       " << firstInt + secondInt << endl;
    cout << " The product of the two integers is :   " << firstInt * secondInt << endl;
    cout << " The whole number quotient 1st/2nd is : " << firstInt / secondInt << endl;
    cout << " The remainder of 1st/2nd is :          " << firstInt % secondInt << endl;
    cout << " The float result of 1st/2nd is :       " << static_cast<float>(firstInt) / secondInt << endl;
    cout << " The 1st to the power of the 2nd is :   " << pow(firstInt,secondInt) << endl; 

    //enter and output real numbers
    cout << endl;
    float realNumOne;
    float realNumTwo;
    cout << "Please enter a 1st real number : "; cin >> realNumOne; 
    cout << "Please enter a 2nd real number : "; cin >> realNumTwo;
    cout << endl;
    cout << "The entered 1st real number is : " << realNumOne << endl;
    cout << "The entered 2nd real number is : " << realNumTwo << endl;


    //math operations on real numbers & break up numbers into fract and int
    float x = realNumOne, intPart, fractPart;
    fractPart = modf(x, &intPart);

    float y = realNumTwo, intPartTwo, fractPartTwo;
    fractPartTwo = modf(y, &intPartTwo);

    cout << endl;
    cout << "The sum of the two real numbers is :     " << realNumOne + realNumTwo << endl;
    cout << "The Product of the two real numbers is : " << realNumOne * realNumTwo << endl;
    cout << "The quotient of 1st/2nd is :             " << realNumOne / realNumTwo << endl;
    cout << "The whole number part of 1st number is : " << intPart << endl;
    cout << "The whole number part of 2nd number is : " << intPartTwo << endl;
    cout << "The fractional part of 1st number is :   " << fractPart << endl;
    cout << "The fractional part of 2nd number is :   " << fractPartTwo << endl;


    //integer to convert to float
    cout << endl;
    int intConvert;
    cout << "Please enter an integer to convert to a float : "; cin >> intConvert;
     
    //set precision to show 4 decimals
    cout << fixed << setprecision(4);
    cout << "The integer as a float is : " << static_cast<float>(intConvert) << endl;
    float intConvertTwo;
    cout << endl;
    cout << "Please enter an integer to convert to a float : " ; cin >> intConvertTwo;
    cout << "The float as a integer is : " << static_cast<int>(intConvertTwo) << endl;
    

    //manipulate a string outputting first and last letters and gives length
    cout << endl;
    string firstString;
    cout << "Please enter 1st string : "; cin >> firstString;
    cout << endl << endl;
    cout << "The 1st string is : " << firstString << endl;
    cout << "The length of this string is :       " << firstString.length() << endl;
    cout << "The first letter of this string is : " << firstString[0] << endl;
    cout << "The last letter of this string is :  " << firstString[firstString.length() - 1] << endl;
    cout << endl;

    string secondString;
    cout << "Please enter a 2nd string : ";cin >> secondString;
    cout << endl;
    cout << "The 1st string concatenated with the 2nd string                            : " << firstString + secondString << endl;
    cout << "The 1st string concatenated with the 2nd string with a space in between is : " << firstString + " " + secondString << endl;

    cout << endl;
    cout << "Press the enter key once or twice to end..." << endl; cin.ignore(); cin.get();

    return 0;
}
