/*
Program Name: Rock Paper Scissor
Date: 9/19/23
Author: Oudom Pach
Module Purpose
This program produces the rock paper scissor game looping until user is ready to be done.
*/


#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;


int main() {

    const unsigned short ROCK = 1; 
    const unsigned short PAPER = 2;
    const unsigned short SCISSORS = 3;
    const unsigned short END_GAME = 4;

    int tie = 0;
    int compWin = 0;
    int playerWin = 0;
    
    //gameplay count is one since do while loop always runs the game at least once
    int gamePlayCount = 1; 

    do {

        cout << "Please choose a weapon from the menu below: " << endl
            << "1.> Rock " << endl
            << "2.> Paper " << endl
            << "3.> Scissors " << endl
            << "4.> End Game " << endl;

        cout << endl;
        unsigned short playerInput;
        cout << "Weapon Choice: "; cin >> playerInput;
        cout << endl;

        //checks value of input to weapon
        switch (playerInput)
        {
        case ROCK:
            cout << "Player weapon is: Rock" << endl << endl;
            break;

        case PAPER:
            cout << "Player weapon is: Paper" << endl << endl;
            break;

        case SCISSORS:
            cout << "Player weapon is: Scissors" << endl << endl;
            break;

        case END_GAME:
            cout << "Player weapon is: End game" << endl << endl;
            return 0;
            //suppose to end

        default:
            cout << "Invalid menu choice, please try again" << endl << endl;
            

        }

        if (playerInput == END_GAME) {
            break;
        }

        srand(clock());
        unsigned short computerInput = 1 + (rand() % 3);

        //checks value of input to weapon
        switch (computerInput)
        {
        case ROCK:
            cout << "Computer weapon is: Rock" << endl << endl;
            break;

        case PAPER:
            cout << "Computer weapon is: Paper" << endl << endl;
            break;

        case SCISSORS:
            cout << "Computer weapon is: Scissors" << endl << endl;
            break;

        case END_GAME:
            cout << "Computer weapon is: End game" << endl << endl;


            return 0;

        }

        if (computerInput == playerInput) {
            tie++;
            cout << "It's a tie " << endl << endl;
        }

        if ((computerInput == ROCK) && (playerInput == SCISSORS)) {
            compWin++;
            cout << "Computer wins! " << endl << endl;
        }
        if ((computerInput == PAPER) && (playerInput == ROCK)) {
            compWin++;
            cout << "Computer wins! " << endl << endl;
        }
        if ((computerInput == SCISSORS) && (playerInput == PAPER)) {
            compWin++;
            cout << "Computer wins! " << endl << endl;
        }


        if ((playerInput == ROCK) && (computerInput == SCISSORS)) {
            playerWin++;
            cout << "Player wins! " << endl << endl;
        }
        if ((playerInput == PAPER) && (computerInput == ROCK)) {
            playerWin++;
            cout << "Player wins! " << endl << endl;
        }
        if ((playerInput == SCISSORS) && (computerInput == PAPER)) {
            playerWin++;
            cout << "player wins! " << endl << endl;
        }

        cout << "Number of: " << endl
            << "Ties          : " << tie << endl
            << "Player  Wins  : " << playerWin << endl
            << "Computer Wins :" << compWin << endl;
        cout << endl;
        cout << "Gameplay Count: " << gamePlayCount << endl;
        gamePlayCount++;

        cout << endl;
        cout << "Press the enter key once or twice to continue "; cin.ignore(); cin.get();
        cout << endl;

    } while (true);
    return 0;

}