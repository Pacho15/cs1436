
/*
 assignment 03 compare_control_structure
 9/12/23
 Oudom Pach
 compares floats,ints,and string to see which one is bigger
*/




using namespace std;

#include <iostream>

int main() {
    int firstInt, secondInt;

    cout << "Please enter first  integer number: "; cin >> firstInt;
    cout << endl; 
    cout << "Please enter second integer number: "; cin >> secondInt;
    cout << endl;

    if (firstInt == secondInt) {
        cout << "Both integers equal. " << endl;
    }
    else {
        cout << "Integers not equal. " << endl;
    }
    


    float firstFloat, secondFloat;

    cout << endl;
    cout << "Please enter first  float number: "; cin >> firstFloat;
    cout << endl; 
    cout << "Please enter second float number: "; cin >> secondFloat;

    if (firstFloat > secondFloat) {
        cout << endl;

        cout << "The Greater Float is: " << firstFloat << endl;
    }
    else if (secondFloat > firstFloat) {
        cout << endl;
        cout << "The Greater Float is: " << secondFloat << endl;
    }
    else {
        cout << endl;
        cout << "The floats are the same. " << endl;
    }
    

    cout << endl;

    string firstString, secondString; 

    cout << "Please enter first  string (no spaces): "; cin >> firstString;
    cout << endl;
    cout << "Please enter second string (no spaces): "; cin >> secondString;
    cout << endl; 

    if (firstString > secondString) {
        cout << "The greater string is: " << firstString << endl;
    }
    else if (firstString < secondString) {
        cout << "The greater string is: " << secondString << endl;
    }
    else {
        cout << "Both strings are equal. " << endl;
    }

    cout << endl;
    cout << "Press the enter key once or twice to end..." << endl;
    cin.ignore(); cin.get();


    return 0;

}