/*
Program Name:  Series Precision Performance
Date:          10-4-23
Author:        Oudom Pach
Program Purpose: calculates and displays the forward double and float series as well as the reverse float and double series upon a given input. 
*/
#include <locale>
#include <iostream>
#include <iomanip>
#include <string>
#include <ctime>
#include <limits.h>
using namespace std;


int main() {
    
    unsigned long num;

    clock_t timeStart;

    float sumForwardFloat = 0;
    double sumForwardDouble = 0, timeForwardFloat, timeForwardDouble;

    cout << "Enter an unsigned integer > 0 : "; cin >> num;
    cout << endl;
    cout.imbue(locale(""));


    timeStart = clock();

    for (unsigned long i = 1; i <= num; i++) {

        sumForwardFloat += ((float)1.0 / (float)i);

    }
    
    timeForwardFloat = (double)(clock() - timeStart) / CLOCKS_PER_SEC;



    timeStart = clock();

    for (unsigned long i = 1; i <= num; i++) {

        sumForwardDouble += (1.0 / i);

    }

    timeForwardDouble = (double)(clock() - timeStart) / CLOCKS_PER_SEC;


    float sumReverseFloat = 0;
    double sumReverseDouble = 0, timeReverseDouble, timeReverseFloat;

    timeStart = clock();

    for (unsigned long i = 0; i <= num; i++) {

        sumReverseFloat += ((float)1.0 / (float)(num - i + 1));

    }

    timeReverseFloat = (double)(clock() - timeStart) / CLOCKS_PER_SEC;

    timeStart = clock();

    for (unsigned long i = 0; i <= num; i++) {

        sumReverseDouble += (1.0 / (num - i + 1));

    }
    
    timeReverseDouble = (double)(clock() - timeStart) / CLOCKS_PER_SEC; 


    double timeTotal = timeReverseDouble + timeReverseFloat + timeForwardFloat + timeForwardDouble;

    cout << "Forward F(" << num << ") Series:" << endl;
    cout << "==============================" << endl;

    cout << endl;

    cout << "Float  Time Elapsed :" << setw(9) << right << timeForwardFloat << endl;
    cout << "Float  Sum          :" << setw(9) << right << sumForwardFloat << endl;
    cout << endl;
    cout << "Double Time Elapsed :" << setw(9) << right << timeForwardDouble << endl;
    cout << "Double Sum          :" << setw(9) << right << sumForwardDouble << endl;
    cout << endl;

    cout << "Reverse R(" << num << ") Series:" << endl;
    cout << "==============================" << endl;

    cout << endl;

    cout << "Float  Time Elapsed :" << setw(9) << right << timeReverseFloat << endl;
    cout << "Float  Sum          :" << setw(9) << right << sumReverseFloat << endl;
    cout << endl;
    cout << "Double Time Elapsed :" << setw(9) << right << timeReverseDouble << endl;
    cout << "Double Sum          :" << setw(9) << right << sumReverseDouble << endl;
    cout << endl;

    cout << "Total  Time Elapsed :" << setw(9) << right << timeTotal << endl;

    cout << endl << "Press the enter key once or twice to end..."; cin.ignore(); cin.get();
    cout << endl << endl;



    return 0;
}


